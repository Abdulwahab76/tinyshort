import logo from "./logo.svg";
import "./App.css";
import Tiny from "./Tiny";

function App() {
    return (
        <>
            <Tiny />
        </>
    );
}

export default App;
