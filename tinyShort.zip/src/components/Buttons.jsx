import React from "react";
function Button() {
    return (
        <>
            <div className="shell-btns">
                <button>Support</button>
                <button>Wallets</button>
                <button>News</button>
                <button>White Papers</button>
                <button>Roadmap</button>
            </div>
        </>
    );
}
export default Button;
